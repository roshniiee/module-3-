In Postman use below to execute the Functionality
URL: http://localhost:8081/SpringRESTDemo/rest/employee/create/       
Request: POST
Header : Accept:application/json, content-type:application/json
Body:{
	"empId":999,
	"empName":"Pankaj",
	"empSalary":8000,
	"empDepartment":"Java"
}
--------------------------------------------------
URL:http://localhost:8081/SpringWithAngular/rest/employee/delete/1
Request:DELETE